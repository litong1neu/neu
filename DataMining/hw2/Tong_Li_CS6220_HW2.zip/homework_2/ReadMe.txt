Something about the code

Q1:
I spent a lot of time to build the decision tree with code.
You can run the code hw2_p1.py to see the result.
Becasue of some feature gain is the same. So it may show different answer. 


Q2:
the python code runs slow. It takes 5minutes to finish.
run my code with python IDE or -python hw2_p2.py
there are three part of my code A,B,C. They are the small questions in Q2.
If you want to see different result, please modify the code to run A(),B(),or C()