import math
import copy

# tree structure class and function
class Node:
    def __init__(self,feature=None,attributes=None,gain=None,LH=None,decision=None):
        self.name=feature
        self.edge=attributes
        self.edge_LH=LH
        self.children=[]
        self.gain=gain
        self.decision=decision
        if self.decision==None:
            self.edge_entropy = [entropy(low_high[0], low_high[1]) for low_high in LH]
    def __str__(self):
        if self.decision:
            return "{}\n".format(self.decision)
        else:
            return "1:{}\n2:{} 3:{} 4:{} 5:{}\n".format(self.name,self.edge,self.edge_LH,self.edge_entropy,self.gain)

class Table:
    def __init__(self,edu_level,career,years_exp,location,salary):
        self.edu_level=edu_level
        self.career=career
        self.years_exp=years_exp
        self.location=location
        self.salary=salary
        self.size=len(salary)

    def count(self,salary,edu_level=None,career=None,years_exp=None,location=None):
        index_list=[]

        for i in range(self.size):
            if self.salary[i]==salary:
                index_list.append(i)

        if edu_level:
            new_index_list=[]
            for i in index_list:
                if self.salary[i]==salary and self.edu_level[i]==edu_level:
                    new_index_list.append(i)
            index_list=new_index_list

        if career:
            new_index_list=[]
            for i in index_list:
                if self.salary[i]==salary and self.career[i]==career:
                    new_index_list.append(i)
            index_list=new_index_list

        if years_exp:
            new_index_list=[]
            for i in index_list:
                if self.salary[i]==salary and self.years_exp[i]==years_exp:
                    new_index_list.append(i)
            index_list=new_index_list

        if location:
            new_index_list=[]
            for i in index_list:
                if self.salary[i]==salary and self.location[i]==location:
                    new_index_list.append(i)
            index_list=new_index_list

        return len(index_list)

def table_init():
    edu_level=['High School']*2+['College']*2+['High School']+['College']*3+['High School']*3
    career=['Management']*3+['Service']*3+['Management']+['Service']+['Management']+['Service']*2
    years_exp=['Less than 3']+['3 to 10']+['Less than 3']+['More than 10']+['3 to 10']*2+['More than 10']+['Less than 3']+['More than 10']*2+['Less than 3']
    location=['Oregon']+['California']*2+['Oregon']+['California']*3+['Oregon']*3+['California']
    salary=['Low']*2+['High']+['Low']*2+['High']*2+['Low']+['High']+['Low']*2

    return Table(edu_level,career,years_exp,location,salary)

def test_table_init():
    edu_level=['College']*3+['High School']*2
    career=['Management']+['Service']*3+['Management']
    years_exp=['Less than 3']+['3 to 10']+['Less than 3']+['More than 10']*2
    location=['Oregon']*2+['California']*3
    salary=['Low']*2+['High']*3

    return Table(edu_level,career,years_exp,location,salary)
#---------------------------------------

#build decision tree
def helper1(features,table,kargs,info):
    #can I make decision?
    low=table.count('Low',**kargs)
    high=table.count('High',**kargs)
    #print(low,high)
    if low==0:
        return Node(decision='High')
    if high==0:
        return Node(decision='Low')

    #find the best feature for current node
    feature_gain = 0
    node_key=None
    node_LH_list=[]
    node_attributes=[]

    for key,attributes_list in features.items():
        LH_list=[]
        kargs1=kargs.copy()
        kargs2=kargs.copy()
        for i in range(len(attributes_list)):
            kargs1[key]=attributes_list[i]
            LH_list.append([table.count('Low',**kargs1),table.count('High',**kargs1)])
        temp_gain=info-information(LH_list)
        if temp_gain >= feature_gain:
            node_key = key
            feature_gain = temp_gain
            node_LH_list = LH_list
            node_attributes = features[key]

    root = Node(node_key, node_attributes, feature_gain, node_LH_list)

    #generate children
    for i in range(len(node_attributes)):
        kargs2[node_key] = node_attributes[i]
        low = node_LH_list[i][0]
        high = node_LH_list[i][1]
        if low!=0 or high!=0:
            ff = features.copy()
            del ff[node_key]
            root.children.append(helper1(ff,table,kargs2,root.edge_entropy[i]))

    return root

def build_tree(table):
    global fw1
    table = table_init()
    features={'edu_level':['High School','College'],
              'career':['Management','Service'],
             'years_exp':['Less than 3','3 to 10','More than 10'],
             'location':['Oregon','California']
             }
    root=helper1(features,table,{},0.95)
    return root
#---------------------------------------

#print desicion tree function
def printDT(root,indent):
    print('\t' * indent, end='')
    print('{} gain = {}'.format(root.name, root.gain))
    for i in range(len(root.children)):
        print('\t' * (indent + 1), end='')
        print('{}.({}) {}, {}, {}'.format(i + 1, root.edge[i], root.edge_LH[i][0], root.edge_LH[i][1], root.edge_entropy[i]))
        if root.children[i].decision==None:
            printDT(root.children[i],indent+2)
        else:
            print('\t' * (indent + 2), end='')
            print(root.children[i].decision)

#print pruning tree
def printDT1(root,indent):
    print('\t' * indent, end='')
    print('{}'.format(root.name))
    for i in range(len(root.children)):
        print('\t' * (indent + 1), end='')
        print('{}.({})'.format(i + 1, root.edge[i]))
        if root.children[i].decision==None:
            printDT1(root.children[i],indent+2)
        else:
            print('\t' * (indent + 2), end='')
            print(root.children[i].decision)
#---------------------------------------

#data process
def entropy(low,high):
    pl=1
    ph=1
    if low!=0:
        pl=low/(low+high)
    if high!=0:
        ph=high/(low+high)
    res=-(pl*math.log(pl,2)+ph*math.log(ph,2))
    if res:
        return res
    return 0

def test_count(root,test_table):
    count=0
    instance={}

    for i in range(5):
        instance['edu_level']=test_table.edu_level[i]
        instance['career'] = test_table.career[i]
        instance['years_exp'] = test_table.years_exp[i]
        instance['location'] = test_table.location[i]
        instance['salary'] = test_table.salary[i]
        node = root
        while node.decision==None:
            path=instance[node.name]
            I=node.edge.index(path)
            node=node.children[I]
        if node.decision==instance['salary']:
            count+=1
    return count

def information(LH_list):
    data_list=[]
    N=0
    for l in LH_list:
        low=l[0]
        high=l[1]
        N+=low+high
        data_list.append((low+high,entropy(low,high)))
    if N:
        return sum([x*y/N for x,y in data_list])
    return 0
#---------------------------------------

#functions for tree pruning
def prune(root,test_table):
    for i in range(len(root.edge)):
        root.children[i]=prune_helper(root,root.children[i],i,test_table,root)

def prune_helper(par,node,child,test_table,root):
    if node.decision!=None:
        return Node(decision=node.decision)

    for i in range(len(node.children)):
        if node.children[i].decision==None:
            node.children[i]=prune_helper(node,node.children[i],i,test_table,root)
    tmp=par.children[child]
    old_correct=test_count(root,test_table)
    par.children[child]=Node(decision='High')
    high_correct=test_count(root,test_table)
    par.children[child]=Node(decision='Low')
    low_correct=test_count(root,test_table)
    if old_correct>high_correct and old_correct>high_correct:
        return tmp
    elif high_correct>low_correct:
        return Node(decision='High')
    else:
        return Node(decision='Low')
#---------------------------------------

def main():
    #print the tree before pruning
    table=table_init()
    print('Top 7,4,0.95')
    root=build_tree(table)
    printDT(root,0)

    #print the tree after pruning
    test_table=test_table_init()
    root1=copy.deepcopy(root)
    prune(root1,test_table)
    print('-----------pruning decision tree-----------')
    printDT1(root1,0)
    return 0

if __name__ == '__main__':
    main()