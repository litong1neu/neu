import numpy as np
import csv
import math

def readFile(name):
	with open(name,"r") as dataFile:
		datareader = csv.reader(dataFile)
		dataList = []
		dataFile.readline()
		for row in datareader:
			if len(row) != 0 :
				row.pop(0)
				l = list(map(float,row))
				dataList.append(l)
	dataFile.close()
	A = np.array(dataList)
	Y = A[:,-1].reshape(-1,1)
	X = A[:,0:-1]
	return (X,Y)

#calculate two point distance
def pointDist(m1,m2):
	total = 0
	A = m1-m2
	total=np.dot(A,A.T)
	return math.sqrt(total)

#find the neighbors of one test instance
def neighbors(X_train,test_instance,k):
	index_Dist = [(row,pointDist(test_instance,X_train[row])) for row in range(len(X_train))]
	'''
	row_train = len(X_train)
	for row2  in range(row_train):
		xtoy=pointDist(test_instance,X_train[row2])
		index_Dist.append((row2,xtoy))
	'''
	l=sorted(index_Dist,key=lambda x:x[1])
	test_map=l[:k]
	return test_map
#---------------------------------------

#KNN for (a)
def KNN(k,X_train,Y_train,X_test,Y_test):
	row_test,col_test=X_test.shape
	correct=0
	for i in range(row_test):
		yes=no=spam=0
		test_map=neighbors(X_train,X_test[i],k)
		for j in range(k):
			if Y_train[test_map[j][0]][0] == 1:
				yes+=1
			else:
				no+=1
		if yes>no:
			spam=1
		else:
			spam=0
		if spam == Y_test[i][0]:
			correct+=1
	return "correct:{},total:{}".format(correct,row_test)

#KNN for (c)
def KNN_c(k,X_train,X_test,Y_train,decision):
	row_test,col_test=X_test.shape
	for i in range(row_test):
		yes=no=0
		test_map=neighbors(X_train,X_test[i],k)
		for j in range(k):
			if Y_train[test_map[j][0]][0] == 1:
				yes+=1
			else:
				no+=1
		if yes>no:
			decision[i].append('spam')
		else:
			decision[i].append('no')
# ---------------------------------------

#data process
def average(datalist):
	return sum(datalist)/len(datalist)

def standard_var(datalist,miu):
	total=0
	N=len(datalist)
	for i in range(N):
		total+=(datalist[i]-miu)**2
	return math.sqrt(total/N)

def zscore(X_old):
	X=X_old.copy()
	row,col=X.shape
	for j in range(col):
		datalist=X[:,j]
		miu=average(datalist)
		sigma=standard_var(datalist,miu)
		for i in range(row):
			X[i][j]=(datalist[i]-miu)/sigma
	return X
#---------------------------------------

#print the data for (c)
def c_print(decision,file_name):
	for i in range(len(decision)):
		print ("t{}:".format(i+1),decision[i],file=file_name)

#Question A
def A(X_train,X_test,Y_train,Y_test):
	klist = [1, 5, 11, 21, 41, 61, 81, 101, 201, 401]
	for k in klist:
		print('{}:'.format(k), KNN(k, X_train, Y_train, X_test, Y_test))

#Question B
def B(X_train_normal,X_test_normal,Y_train,Y_test):
	klist = [1, 5, 11, 21, 41, 61, 81, 101, 201, 401]
	for k in klist:
		print('{}:'.format(k), KNN(k, X_train_normal, Y_train, X_test_normal, Y_test))

#Question C
def C(X_train_normal,X_test_50,Y_train):
	decision = []
	klist = [1, 5, 11, 21, 41, 61, 81, 101, 201, 401]
	for i in range(50):
		decision.append([])
	for k in klist:
		KNN_c(k, X_train_normal, X_test_50, Y_train, decision)
	f1=open('sample.txt','w')
	c_print(decision,f1)
	f1.close()
#---------------------------------------

def main():
	X_train,Y_train = readFile('spam_train.csv')
	X_test,Y_test = readFile('spam_test.csv')
	X_train_normal=zscore(X_train)
	X_test_normal=zscore(X_test)
	X_test_50=X_test_normal[0:50,:]

#A for question(a);B for question(b);C for question(c)
	A(X_train,X_test,Y_train,Y_test)
	#B(X_train_normal,X_test_normal,Y_train,Y_test)
	#C(X_train_normal,X_test_50,Y_train)

	return 0

if __name__ == '__main__':
	main()

