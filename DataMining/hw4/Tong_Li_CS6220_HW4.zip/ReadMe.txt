Both program run in python with numpy.
each takes at least 10min. 