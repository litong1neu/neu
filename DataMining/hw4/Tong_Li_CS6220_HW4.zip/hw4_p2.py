import numpy as np
import matplotlib.pyplot as plt
import csv
import math

# -------------------------------------------------------------------------------

def readFile(name):
    dataFile = open(name, 'r')
    datareader = csv.reader(dataFile)
    dataList = []
    for line in datareader:
        dataList.append(list(map(float, line)))
    dataFile.close()
    A = np.array(dataList)
    Y = A[:, -1].reshape(-1, 1)
    X = A[:, 0:-1]
    return (X, Y)

# -------------------------------------------------------------------------------

def pointDist(m1, m2):
    total = 0
    A = m1 - m2
    total = np.dot(A, A.T)
    return math.sqrt(total)


def neighbors(X_train, test_instance, k):
    index_Dist = [(row, pointDist(test_instance, X_train[row])) for row in range(len(X_train))]
    l = sorted(index_Dist, key=lambda x: x[1])
    test_map = l[:k]
    return test_map


def KNN(k, X_train, Y_train, X_test, Y_test):
    correct = 0
    yes = no = spam = 0
    test_map = neighbors(X_train, X_test, k)
    for j in range(k):
        if Y_train[test_map[j][0]][0] == 1:
            yes += 1
        else:
            no += 1
    if yes > no:
        spam = 1
    else:
        spam = 0
    if spam == Y_test[0]:
        correct += 1
    return correct


# -------------------------------------------------------------------------------

def CV(X_m, Y_m):
    row, col = X_m.shape
    correct = 0
    total = row
    for i in range(row):
        X_test = X_m[i]
        Y_test = Y_m[i]
        X_train = np.concatenate((X_m[0:i, :], X_m[i + 1:, :]), axis=0)
        Y_train = np.concatenate((Y_m[0:i, :], Y_m[i + 1:, :]), axis=0)
        res = KNN(7, X_train, Y_train, X_test, Y_test)
        correct += res
    return correct / total





# -------------------------------------------------------------------------------

def average(datalist):
    return sum(datalist) / len(datalist)


def standard_var(datalist, miu):  # sqrt(E[X^2]-E[X]^2)
    d_square = datalist[:]
    d_square = d_square * d_square
    miu_square = average(d_square)
    s = miu_square - miu ** 2
    return math.sqrt(s)


def cov(x_list, y_list):  # Cov(X,Y) = E[(X-E[X])(Y-E[Y])] = E[XY]-E[X]E[Y]
    d_xy = x_list * y_list
    e_xy = average(d_xy)
    e_x = average(x_list)
    e_y = average(y_list)
    return e_xy - e_x * e_y

def zscore(X_old):
    X = X_old.copy()
    row, col = X.shape
    for j in range(col):
        datalist = X[:, j]
        miu = average(datalist)
        sigma = standard_var(datalist, miu)
        for i in range(row):
            X[i][j] = (datalist[i] - miu) / sigma
    return X
# -------------------------------------------------------------------------------

def select_col(X,features):    #features=[ABCDEFG]
    col=features[0]
    m=len(features)
    X_m = X[:, col]
    X_m = np.reshape(X_m,(-1,1))
    if m != 1:
        for i in range(1,m):
            col = features[i]
            tmp=X[:, col]
            tmp=np.reshape(tmp,(-1,1))
            X_m = np.concatenate((X_m, tmp), axis=1)
    return X_m

def plot(xlist,ylist):
    axes = plt.gca()
    axes.set_xlim([0, 40])
    plt.plot(xlist,ylist,'r')
    plt.xlabel('m')
    plt.ylabel('accuracy')
    plt.show()

def next_features(feature_set,best_features):
    for id in best_features:
        feature_set.discard(id)
    selected_features_list=[]
    for f in feature_set:
        tmp=best_features[:]
        tmp.append(f)
        selected_features_list.append(tmp)
    return selected_features_list

def main():
    X, Y = readFile("veh-prime.csv")
    num_features = 36
    #X=X[:100]
    #Y=Y[:100]
    X_z = zscore(X)
    selected_features_list=[[i] for i in range(36)]
    feature_set = {i for i in range(36)}
    step_list=[]
    while True:
        if len(feature_set)==0:
            print("feature_set empty!!!!!!!!!!!!!!")
            break
        accuracy=0
        best_features=[]
        for i in range(len(selected_features_list)):
            features=selected_features_list[i][:]
            X_selected=select_col(X_z,features)
            accuracy_tmp=CV(X_selected,Y)
            if accuracy_tmp>accuracy:
                best_features=features[:]
                accuracy=accuracy_tmp
        if step_list and accuracy<=step_list[-1][1]:
            break
        step_list.append((best_features[:],accuracy))
        selected_features_list=next_features(feature_set,best_features)
    print("step_list: ",step_list)
if __name__ == "__main__":
    main()
