import numpy as np
import matplotlib.pyplot as plt
import csv
import math


# -------------------------------------------------------------------------------

def pointDist(m1, m2):
    total = 0
    A = m1 - m2
    total = np.dot(A, A.T)
    return math.sqrt(total)


def neighbors(X_train, test_instance, k):
    index_Dist = [(row, pointDist(test_instance, X_train[row])) for row in range(len(X_train))]
    l = sorted(index_Dist, key=lambda x: x[1])
    test_map = l[:k]
    return test_map


def KNN(k, X_train, Y_train, X_test, Y_test):
    correct = 0
    yes = no = spam = 0
    test_map = neighbors(X_train, X_test, k)
    for j in range(k):
        if Y_train[test_map[j][0]][0] == 1:
            yes += 1
        else:
            no += 1
    if yes > no:
        spam = 1
    else:
        spam = 0
    if spam == Y_test[0]:
        correct += 1
    return correct


# -------------------------------------------------------------------------------

def CV(X_m, Y_m):
    row, col = X_m.shape
    correct = 0
    total = row
    for i in range(row):
        X_test = X_m[i]
        Y_test = Y_m[i]
        X_train = np.concatenate((X_m[0:i, :], X_m[i + 1:, :]), axis=0)
        Y_train = np.concatenate((Y_m[0:i, :], Y_m[i + 1:, :]), axis=0)
        #print("{}:{}".format(i,Y_train))
        res = KNN(7, X_train, Y_train, X_test, Y_test)
        correct += res
    #print("correct: {}, total: {}".format(correct,total))
    return correct / total


# -------------------------------------------------------------------------------

class Feature:
    def __init__(self, l, y_list, name):
        self.l = np.array(l)
        self.r = abs(cov(self.l, y_list.T[0]))
        self.name = name

    def __lt__(self, other):
        return self.r < other.r

    def __str__(self):
        return "Id:{}".format(self.name)


# ------------------------------------------------------------------------------

def readFile(name):
    dataFile = open(name, 'r')
    datareader = csv.reader(dataFile)
    dataList = []
    for line in datareader:
        dataList.append(list(map(float, line)))
    dataFile.close()
    A = np.array(dataList)
    Y = A[:, -1].reshape(-1, 1)
    X = A[:, 0:-1]
    return (X, Y)


# -------------------------------------------------------------------------------

def average(datalist):
    return sum(datalist) / len(datalist)


def standard_var(datalist, miu):  # sqrt(E[X^2]-E[X]^2)
    d_square = datalist[:]
    d_square = d_square * d_square
    miu_square = average(d_square)
    s = miu_square - miu ** 2
    return math.sqrt(s)


def cov(x_list, y_list):  # Cov(X,Y) = E[(X-E[X])(Y-E[Y])] = E[XY]-E[X]E[Y]
    d_xy = x_list * y_list
    e_xy = average(d_xy)
    e_x = average(x_list)
    e_y = average(y_list)
    return e_xy - e_x * e_y


def pearson(x_list, y_list):
    mean_x = average(x_list)
    mean_y = average(y_list)
    cov_xy = cov(x_list, y_list)
    correlation = cov_xy / (standard_var(x_list, mean_x) * standard_var(y_list, mean_y))
    return correlation

def zscore(X_old):
    X = X_old.copy()
    row, col = X.shape
    for j in range(col):
        datalist = X[:, j]
        miu = average(datalist)
        sigma = standard_var(datalist, miu)
        for i in range(row):
            X[i][j] = (datalist[i] - miu) / sigma
    return X
# -------------------------------------------------------------------------------

def select_m(X,m,feature_list):
    X_m = X[:, feature_list[0].name]
    X_m = np.reshape(X_m,(-1,1))
    if m != 1:
        for i in range(1,m):
            col = feature_list[i].name
            tmp=X[:, col]
            tmp=np.reshape(tmp,(-1,1))
            X_m = np.concatenate((X_m, tmp), axis=1)
    return X_m

def plot(xlist,ylist):
    axes = plt.gca()
    axes.set_xlim([0, 40])
    plt.plot(xlist,ylist,'r')
    plt.xlabel('m')
    plt.ylabel('accuracy')
    plt.show()

def main():
    X, Y = readFile("veh-prime.csv")
    num_features = 36

    #X=X[:200]
    #Y=Y[:200]
    X_z = zscore(X)
    feature_list = []
    for i in range(36):
        f = Feature(X_z[:, i], Y, i)
        feature_list.append(f)
    feature_list.sort(reverse=True)

    for f in feature_list:
        print(f,end=" ")
    '''
    m=5
    X_m = select_m(X, m, feature_list)
    print(X_m.shape)
    CV(X_m, Y)
    '''

    cv_list=[]
    m_list=[x for x in range(1,37)]
    for m in range(1,37):
        X_m = select_m(X_z,m,feature_list)
        cv_list.append(CV(X_m,Y))
    print(cv_list)
    plot(m_list,cv_list)

if __name__ == "__main__":
    main()
