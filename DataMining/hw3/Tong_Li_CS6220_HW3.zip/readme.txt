use python3 to run the program. After 5 mins it will show the plot.

