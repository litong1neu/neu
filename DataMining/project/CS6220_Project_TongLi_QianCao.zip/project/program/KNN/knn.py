import csv
import numpy
import math
def readFile(name):
    dataFile = open(name, 'r')
    datareader = csv.reader(dataFile)
    instances=[]
    for line in datareader:
        instances.append(line)
    dataFile.close()
    return instances

def X_Y(instances):
    #numeric_index=[4,9,12,13,14,21,15,16,17]  #Id:8 r:0.06825448988565783 Id:1 r:0.04520476874807157 Id:0 r:0.03882517897787411
    # Id:5 r:0.03586336446795146 Id:4 r:0.028856108374600602 Id:2 r:0.027934399434974985
    # Id:7 r:0.025389761311356226 Id:6 r:0.006220631935054227 Id:3 r:0.005803280878230492
    numeric_index=[17,9,4]
    row_len=len(instances)
    col_len=len(instances[0])
    X=[[] for _ in range(row_len-1)]
    Y = [[] for _ in range(row_len - 1)]
    for i in range(1,row_len):
        Y[i-1].append(int(instances[i][col_len-1]))
        for j in numeric_index:
            if j==4:
                str=instances[i][j]
                if str[1]=='0':
                    X[i - 1].append(0)
                else:
                    X[i - 1].append(float(str[1:3]))
            else:
                X[i-1].append(float(instances[i][j]))

    X=numpy.array(X)
    Y=numpy.array(Y)

    return X,Y
# -------------------------------------------------------------------------------

def pointDist(m1, m2):
    total = 0
    A = m1 - m2
    total = numpy.dot(A, A.T)
    return math.sqrt(total)


def neighbors(X_train, test_instance, k):
    index_Dist = [(row, pointDist(test_instance, X_train[row])) for row in range(len(X_train))]
    l = sorted(index_Dist, key=lambda x: x[1])
    test_map = l[:k]
    return test_map


def KNN(k, X_train, Y_train, X_test, Y_test,vote,vote_index):
    row_test, col_test = X_test.shape
    correct = 0
    for i in range(row_test):
        yes = no = spam = 0
        test_map = neighbors(X_train, X_test[i], k)
        for j in range(k):
            if Y_train[test_map[j][0]][0] == 1:
                yes += 1
            else:
                no += 1
        if yes > no:
            vote[vote_index].append(1)
        else:
            vote[vote_index].append(0)
        vote_index+=1


# -------------------------------------------------------------------------------
# LOOCV
def CV(X_m, Y_m,step,k,vote,X_z2,Y2,X_z3,Y3):
    row, col = X_m.shape
    total = row
    start=0
    end=step
    while start < row:
        X_test = X_m[start:end]
        Y_test = Y_m[start:end]
        X_train = numpy.concatenate((X_m[0:start, :], X_m[end:, :]), axis=0)
        Y_train = numpy.concatenate((Y_m[0:start, :], Y_m[end:, :]), axis=0)
        #print("{}:{}".format(i,Y_train))
        KNN(k, X_train, Y_train, X_test, Y_test,vote,start)
        KNN(k, X_z2, Y2, X_test, Y_test, vote, start)
        KNN(k, X_z3, Y3, X_test, Y_test, vote, start)
        start+=step
        end+=step
        #print(start)
        if end>=row:
            end=row
    #print("correct: {}, total: {}".format(correct,total))


# -------------------------------------------------------------------------------
# data process
def average(datalist):
    return sum(datalist) / len(datalist)


def standard_var(datalist, miu):
    total = 0
    N = len(datalist)
    for i in range(N):
        total += (datalist[i] - miu) ** 2
    return math.sqrt(total / (N-1))


def zscore(X_old):
    X = X_old.copy()
    row, col = X.shape
    for j in range(col):
        datalist = X[:, j]
        miu = average(datalist)
        sigma = standard_var(datalist, miu)
        for i in range(row):
            X[i][j] = (datalist[i] - miu) / sigma
    return X


# ---------------------------------------

def main():
    #instances=readFile('sample_bag1.csv')
    instances1 = readFile('bag1.csv')
    X1,Y1=X_Y(instances1)
    X_z1=zscore(X1)

    instances2 = readFile('bag2.csv')
    X2,Y2=X_Y(instances2)
    X_z2=zscore(X2)

    instances3 = readFile('bag3.csv')
    X3,Y3=X_Y(instances3)
    X_z3=zscore(X3)

    vote=[[] for _ in range(len(X_z1))]
    res=[]
    k_list=[401]

    step=1000
    for k in k_list:
        CV(X_z1,Y1,step,k,vote,X_z2,Y2,X_z3,Y3)

    f=open('vote_3features.csv','w')
    f.write('vote1,vote2,vote3,label\n')
    for i in range(len(vote)):
        l=list(map(str,vote[i]))
        l.append(str(Y1[i][0]))
        line=','.join(l)+'\n'
        f.write(line)
    f.close()
if __name__ == '__main__':
    main()