import numpy
import matplotlib.pyplot as plt
import csv
import math
# -------------------------------------------------------------------------------

def pointDist(m1, m2):
    total = 0
    A = m1 - m2
    total = numpy.dot(A, A.T)
    return math.sqrt(total)


def neighbors(X_train, test_instance, k):
    index_Dist = [(row, pointDist(test_instance, X_train[row])) for row in range(len(X_train))]
    l = sorted(index_Dist, key=lambda x: x[1])
    test_map = l[:k]
    return test_map


def KNN(k, X_train, Y_train, X_test, Y_test):
    row_test, col_test = X_test.shape
    correct = 0
    for i in range(row_test):
        yes = no = spam = 0
        test_map = neighbors(X_train, X_test[i], k)
        for j in range(k):
            if Y_train[test_map[j][0]][0] == 1:
                yes += 1
            else:
                no += 1
        if yes > no:
            spam = 1
        else:
            spam = 0
        if spam == Y_test[i][0]:
            correct += 1
    return correct


# -------------------------------------------------------------------------------

class Feature:
    def __init__(self, col, Y, name):
        self.col = numpy.array(col)
        self.r = abs(cov(self.col, (Y.T)[0])) # change Y to list
        self.name = name

    def __lt__(self, other):
        return self.r < other.r

    def __str__(self):
        return "Id:{} r:{}".format(self.name,self.r)


# ------------------------------------------------------------------------------

def readFile(name):
    dataFile = open(name, 'r')
    datareader = csv.reader(dataFile)
    instances=[]
    for line in datareader:
        instances.append(line)
    dataFile.close()
    return instances

def X_Y(instances):
    numeric_index=[4,9,12,13,14,21,15,16,17]
    row_len=len(instances)
    col_len=len(instances[0])
    X=[[] for _ in range(row_len-1)]
    Y = [[] for _ in range(row_len - 1)]
    for i in range(1,row_len):
        Y[i-1].append(float(instances[i][col_len-1]))
        for j in numeric_index:
            if j==4:
                str=instances[i][j]
                if str[1]=='0':
                    X[i - 1].append(0)
                else:
                    X[i - 1].append(float(str[1:3]))
            else:
                X[i-1].append(float(instances[i][j]))

    X=numpy.array(X)
    Y=numpy.array(Y)

    return X,Y
# -------------------------------------------------------------------------------

def average(datalist):
    return sum(datalist) / len(datalist)


def standard_var(datalist, miu):  # sqrt(E[X^2]-E[X]^2)
    d_square = datalist[:]
    d_square = d_square * d_square
    miu_square = average(d_square)
    s = miu_square - miu ** 2
    return math.sqrt(s)


def cov(x_list, y_list):  # Cov(X,Y) = E[(X-E[X])(Y-E[Y])] = E[XY]-E[X]E[Y]
    d_xy = x_list * y_list
    e_xy = average(d_xy)
    e_x = average(x_list)
    e_y = average(y_list)
    return e_xy - e_x * e_y


def pearson(x_list, y_list):
    mean_x = average(x_list)
    mean_y = average(y_list)
    cov_xy = cov(x_list, y_list)
    correlation = cov_xy / (standard_var(x_list, mean_x) * standard_var(y_list, mean_y))
    return correlation

def zscore(X_old):
    X = X_old.copy()
    row, col = X.shape
    for j in range(col):
        datalist = X[:, j]
        miu = average(datalist)
        sigma = standard_var(datalist, miu)
        for i in range(row):
            X[i][j] = (datalist[i] - miu) / sigma
    return X
# -------------------------------------------------------------------------------

# LOOCV
def CV(X_m, Y_m,step,k):
    row, col = X_m.shape
    correct = 0
    total = row
    start=0
    end=step
    while start < row:
        X_test = X_m[start:end]
        Y_test = Y_m[start:end]
        X_train = numpy.concatenate((X_m[0:start, :], X_m[end:, :]), axis=0)
        Y_train = numpy.concatenate((Y_m[0:start, :], Y_m[end:, :]), axis=0)
        #print("{}:{}".format(i,Y_train))
        res = KNN(k, X_train, Y_train, X_test, Y_test)
        correct += res

        start+=step
        end+=step
        #print(start)
        if end>=row:
            end=row
    #print("correct: {}, total: {}".format(correct,total))
    return correct / total
# -------------------------------------------------------------------------------
def select_m(X,m,feature_list):
    X_m = X[:, feature_list[0].name]
    X_m = numpy.reshape(X_m,(-1,1))
    if m != 1:
        for i in range(1,m):
            col = feature_list[i].name
            tmp=X[:, col]
            tmp=numpy.reshape(tmp,(-1,1))
            X_m = numpy.concatenate((X_m, tmp), axis=1)
    return X_m

def plot(xlist,ylist):
    axes = plt.gca()
    axes.set_xlim([0, 40])
    plt.plot(xlist,ylist,'r')
    plt.xlabel('m')
    plt.ylabel('accuracy')
    plt.show()

# -------------------------------------------------------------------------------
def main():
    instances = readFile('bag1.csv')
    X,Y=X_Y(instances)

    X_z=zscore(X)
    num_features = len(X[0])

    feature_list = []
    for i in range(num_features):
        f = Feature(X_z[:, i], Y, i)
        feature_list.append(f)
    feature_list.sort(reverse=True)

    for f in feature_list:
        print(f,end=" ")

    cv_list=[]
    n=len(feature_list)
    m_list=[x for x in range(2,n+1)]
    for m in range(2,n+1):
        X_m = select_m(X_z,m,feature_list)
        res=CV(X_m,Y,1000,101)
        print(res)
        cv_list.append(res)
    print(cv_list)
    plot(m_list,cv_list)
if __name__ == "__main__":
    main()