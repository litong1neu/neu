import csv

def readFile(name):
    dataFile = open(name, 'r')
    datareader = csv.reader(dataFile)
    instances=[]
    for line in datareader:
        instances.append(line)
    dataFile.close()
    return instances

def X_Y(instances):
    row_len=len(instances)
    col_len=len(instances[0])
    X=[[] for _ in range(row_len-1)]
    Y = [[] for _ in range(row_len - 1)]
    for i in range(1,row_len):
        Y[i-1].append(int(instances[i][col_len-1]))
        for j in range(col_len-1):
            X[i-1].append(int(instances[i][j]))
    return X,Y

def main():
    instances = readFile('vote_3features.csv')
    X,Y=X_Y(instances)

    row_len=len(Y)
    res=[]
    for i in range(row_len):
        if sum(X[i])>=2:
            res.append(1)
        else:
            res.append(0)
    correct=0
    for i in range(row_len):
        if res[i]==Y[i][0]:
            correct+=1
    print(correct/row_len)

if __name__ == "__main__":
    main()