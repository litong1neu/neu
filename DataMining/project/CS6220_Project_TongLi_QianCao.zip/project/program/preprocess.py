import csv

def readFile(name):
    dataFile = open(name, 'r')
    datareader = csv.reader(dataFile)
    instances=[]
    for line in datareader:
        instances.append(line)
    dataFile.close()
    return instances

def unique_ID(instances):
    p_id=set()
    length=len(instances)
    col=len(instances[0])
    pop_num=set()
    for i in range(1,length):
        instances[i][18]=diag_classify(instances[i][18])
        instances[i][19]=diag_classify(instances[i][19])
        instances[i][20]=diag_classify(instances[i][20])
        if instances[i][col-1]=='<30':
            instances[i][col - 1]='1'
        else:
            instances[i][col - 1]='0'
        flag=0
        for j in range(col):
            if j not in [5,10,11,18,19,20] and instances[i][j]=='?':
                pop_num.add(i)
                flag=1
                break
        if flag==0:
            if instances[i][7] in ['7','9','10','11','12','13','14','18','19','20','21','25','26']:
                pop_num.add(i)
                continue
                '''
            if instances[i][6] in ['5','6','8']:
                pop_num.add(i)
                continue
                '''
                '''
            if instances[i][8] in ['9','15','17','20','21']:
                pop_num.add(i)
                continue
                '''
            if instances[i][1] in p_id:
                pop_num.add(i)
            else:
                p_id.add(instances[i][1])
    new_instances=[]
    for i in range(length):
        if i not in pop_num:
            new_instances.append(instances[i])
    return new_instances


def diag_classify(str):
    if str.isdigit():
        code=int(str)
        if code==785 or (code>=390 and code<=459):
            return 'Circulatory'
        elif code==786 or (code>=460 and code<=519):
            return 'Respiratory'
        elif code==787 or (code>=520 and code<=579):
            return 'Digestive'
        elif code>=250 and code<251:
            return 'Diabetes'
        elif code>=800 and code<=999:
            return 'Injury'
        elif code>=710 and code<=739:
            return 'Musculoskeletal'
        elif code==788 or code>=580 and code<=629:
            return 'Genitourinary'
        elif code==780 or code==781 or code==784 or (code>=790 and code<=799) or (code>=240 and code<=279) or code==782 \
            or (code>=680 and code<=709) or (code>=1 and code<=139):
            return 'Neoplasms'

    return 'Other' if str!='?' else 'Normal'
def main():
    instances=unique_ID(readFile('origin.csv'))
    label0=0
    label1=0
    f=open('preprocess1.csv','w')
    for l in instances:
        if l[-1]=='0':
            label0+=1
        if l[-1]=='1':
            label1+=1
        line=','.join(l)+'\n'
        f.write(line)
    f.close()

    print("total number of class 0 (’NO’ and ’>30’) instances: {}\n"
          "total number of class 1 (’< 30’) instances: {}".format(label0,label1))
if __name__ == "__main__":
    main()