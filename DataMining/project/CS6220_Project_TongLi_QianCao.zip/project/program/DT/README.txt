There are three python code files for decision tree:
            dt.py
            bagging_for_bulk_classification.py
            boosting_for_bulk_classification.py

You need to install DecisionTree-3.4.3 firstly. The link is https://pypi.python.org/pypi/DecisionTree

dt.py can directly run with bag1.csv and bad11.csv existing.
The other two code files can run with command line like:
python bagging_for_bulk_classification.py  training.csv  test.csv  out.csv
python boosting_for_bulk_classification.py  training.csv  test.csv  out.csv

