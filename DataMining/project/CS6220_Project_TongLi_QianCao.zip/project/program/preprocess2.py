import csv
import random
def readFile(name):
    dataFile = open(name, 'r')
    datareader = csv.reader(dataFile)
    instances=[]
    for line in datareader:
        instances.append(line)
    dataFile.close()
    return instances

def distint(instances):
    yes=[]
    no=[]
    row_len=len(instances)
    col_len=len(instances[0])
    for i in range(1,row_len):
        if instances[i][col_len-1]=='1':
            yes.append(i)
        else:
            no.append(i)
    return yes,no

def main():
    instances = readFile('preprocess.csv')

    yesL,noL=distint(instances)

    n=len(yesL)
    set1=set()
    set2=set()
    set3=set()
#three bags with 'yes'
    while len(set1)!=n:
        set1.add(random.choice(noL))
    while len(set2)!=n:
        set2.add(random.choice(noL))
    while len(set3)!=n:
        set3.add(random.choice(noL))

# shuffle the indexes in the bag
    bag1=list(set1)
    bag2=list(set2)
    bag3=list(set3)
    bag1.extend(yesL)
    bag2.extend(yesL)
    bag3.extend(yesL)

    random.shuffle(bag1)
    random.shuffle(bag2)
    random.shuffle(bag3)

#generate three files for next step analysis
    f=open('bag1.csv','w')
    line=','.join(instances[0])+'\n'
    f.write(line)
    for i in bag1:
        line=','.join(instances[i])+'\n'
        f.write(line)
    f.close()

    f=open('bag2.csv','w')
    line=','.join(instances[0])+'\n'
    f.write(line)
    for i in bag2:
        line=','.join(instances[i])+'\n'
        f.write(line)
    f.close()

    f=open('bag3.csv','w')
    line=','.join(instances[0])+'\n'
    f.write(line)
    for i in bag3:
        line=','.join(instances[i])+'\n'
        f.write(line)
    f.close()

if __name__ == "__main__":
    main()