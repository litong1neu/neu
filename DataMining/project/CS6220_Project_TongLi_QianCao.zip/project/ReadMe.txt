Result: run "project/program/Final/vote.py" to get the final prediction

It will take hours to build the training model so I must deal with it step by step. 
1.run "preprocess.py" to separate the raw database to generate the "preprocess.csv".
2.run "preprocess2.py" to generate 3 bags "bag1.csv","bag2.csv","bag3.csv".
3.put 3 bags in KNN file and run "feature_rank.py" to rank the most related feature.
4.find the best numeric features and run "knn.py" to generate "vote_3features.csv". run "accuracy.py" to find the KNN model accuracy.
5.with DT method, because testing the package for days failed to train the model.we have to chose weka and generate the "randomforest.csv"
6.with SVM,we use weka to generate "bag1_res.csv"
7.in "Final" dir,run the "vote.py" to get the accuracy is almost 58%. 