import numpy as np
import matplotlib.pyplot as plt 
import matplotlib.patches as mpatches
import csv
from numpy.linalg import inv

def L2(X,Y,c):
	global N
	N, col=X.shape
	XT_X = np.dot(X.T,X)	
	I = np.identity(col)
	invA = inv((XT_X+c*I))
	w = np.dot(invA,X.T.dot(Y))
	return w
	
def MSE(X,Y,w):
	A = X.dot(w)-Y
	first = A.T.dot(A)
	return first[0][0]/N 

def bestLambda(ylist):
	index = 0
	min = ylist[0]
	for i in range(len(ylist)):
		if min > ylist[i]:
			min = ylist[i]
			index = i
	print(index, min)

def readFile(name):
	with open(name,"r") as dataFile:
		datareader = csv.reader(dataFile)
		dataList = []
		dataFile.readline()
		for row in datareader:
			if len(row) != 0 :
				row.insert(0,1)
				l = list(map(float,row))
				dataList.append(l)
	dataFile.close()
	A = np.array(dataList)
	Y = A[:,-1].reshape(-1,1)
	X = A[:,0:-1]
	return (X,Y)

def plot(xlist,trainplotY,testplotY):
	testline = plt.plot(xlist,testplotY[0:],'r',label = 'testline')
	trainline = plt.plot(xlist,trainplotY[0:],'b', label = 'trainline')
	plt.xlabel('lambda')
	plt.ylabel('MSE ')
	plt.legend()
	plt.show()

def main():	
	name = "train-1000-100.csv"
	X,Y = readFile(name)
	
	N = 0
	trainplotY = []
	wlist = []
	for c in range(151):
		w = L2(X,Y,c)
		wlist.append(w)
		trainplotY.append(MSE(X,Y,w))
	
	name = "test-1000-100.csv"
	X,Y = readFile(name)
	testplotY = []
	for c in range(151):
		testplotY.append(MSE(X,Y,wlist[c]))
	
	xlist = list(range(0,151))
	plot(xlist,trainplotY,testplotY)
	return 0

if __name__ == '__main__':
	main()

