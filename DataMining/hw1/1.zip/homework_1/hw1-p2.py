import numpy as np
import matplotlib.pyplot as plt 
import matplotlib.patches as mpatches
import csv
from numpy.linalg import inv

def L2(X,Y,c):
	global N
	N, col=X.shape
	XT_X = np.dot(X.T,X)	
	I = np.identity(col)
	invA = inv((XT_X+c*I))
	w = np.dot(invA,X.T.dot(Y))
	return w
	
def MSE(X,Y,w):
	A = X.dot(w)-Y
	first = A.T.dot(A)
	return first[0][0]/N 

def readFile(name):
	with open(name,"r") as dataFile:
		datareader = csv.reader(dataFile)
		dataList = []
		dataFile.readline()
		for row in datareader:
			if len(row) != 0 :
				row.insert(0,1)
				l = list(map(float,row))
				dataList.append(l)
	dataFile.close()
	A = np.array(dataList)
	Y = A[:,-1].reshape(-1,1)
	X = A[:,0:-1]
	return (X,Y)

#total: test total times
def averageMSE(start, end, total, X, Y, c,wlist):
	totalMSE = 0
	totalw = 0
	times = 0
	while end <= 1000 and times < total:
		times += 1
		
		X_new = X[start:end, :]	
		Y_new = Y[start:end, :].reshape(-1,1)
		
		w = L2(X_new, Y_new, c)
		totalMSE += MSE(X_new, Y_new, w)
		totalw += w
		
		start += 1
		end += 1
	wlist.append(totalw/times)
	return totalMSE/times

def learningCurve(xlist,ylist_train,ylist_test):
	trainline = plt.plot(xlist,ylist_train,'b', label = 'trainline')	
	testline = plt.plot(xlist,ylist_test,'r',label = 'testline')
	plt.xlabel('size')
	plt.ylabel('MSE ')
	plt.legend()
	plt.show()
	
def main():
	name = "train-1000-100.csv"
	X,Y = readFile(name)
	xlist = list(range(10,1001,10))
	
	N = 0
	c = 1
	ylist_train = []
	wlist = []
	start = 0
	end = 10
	while end <= 1000:
		ylist_train.append(averageMSE(start, end, 10, X, Y, c,wlist))
		end += 10
		
	name = "test-1000-100.csv"
	X,Y = readFile(name)
	ylist_test = []
	for i in range(len(wlist)):
		ylist_test.append(MSE(X, Y, wlist[i]))	
	
	learningCurve(xlist, ylist_train, ylist_test)
	return 0

if __name__ == '__main__':
	main()

