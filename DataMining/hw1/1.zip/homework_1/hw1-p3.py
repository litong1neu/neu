import numpy as np
import matplotlib.pyplot as plt 
import matplotlib.patches as mpatches
import csv
from numpy.linalg import inv

def L2(X,Y,c):
	row, col = X.shape
	XT_X = np.dot(X.T,X)	
	I = np.identity(col)
	invA = inv((XT_X+c*I))
	w = np.dot(invA,X.T.dot(Y))
	return w
	
def MSE(X,Y,w):
	A = X.dot(w)-Y
	first = A.T.dot(A)
	row, col = Y.shape
	return first[0][0]/row 

def readFile(name):
	with open(name,"r") as dataFile:
		datareader = csv.reader(dataFile)
		dataList = []
		dataFile.readline()
		for row in datareader:
			if len(row) != 0 :
				row.insert(0,1)
				l = list(map(float,row))
				dataList.append(l)
	dataFile.close()
	A = np.array(dataList)
	Y = A[:,-1].reshape(-1,1)
	X = A[:,0:-1]
	return (X,Y)

def CV(fold, X, Y, c):
	row, col = X.shape
	step = 	row//fold
	
	start = 0
	end = start + step
	totalMSE = 0
	times = 0
	for i in range(10):
		times += 1
		X_test = X[start:end,:]
		Y_test = Y[start:end,:]
		X_train = np.concatenate((X[0:start,:],X[end:,:]),axis = 0)
		Y_train = np.concatenate((Y[0:start,:],Y[end:,:]),axis = 0)

		w = L2(X_train, Y_train, c)
		totalMSE += MSE(X_test, Y_test, w)
		
		start += step
		end += step
		if end + step > row:
			end = row
	return totalMSE/times
	
def CVCurve(xlist,ylist_train):
	trainline = plt.plot(xlist[:],ylist_train[:],'b', label = 'trainline')	
	plt.xlabel('lambda')
	plt.ylabel('MSE ')
	plt.legend()
	plt.show()

def bestLambda(ylist):
	index = 0
	min = ylist[0]
	for i in range(len(ylist)):
		if min > ylist[i]:
			min = ylist[i]
			index = i
	print(index, min)

def main():
	name = "train-wine.csv"
	X,Y = readFile(name)
	xlist = list(range(151))
	ylist = []
	for c in range(151):	
		ylist.append(CV(10,X,Y,c))
	bestLambda(ylist)
	CVCurve(xlist,ylist)
	return 0

if __name__ == '__main__':
	main()

